﻿namespace PRELIM_LAB1_BSIT_31A3_RACHELLEANNE_LUCBAN.Models
{
    public class Student
    {
            public string Name { get; set; }
            public int Age { get; set; }
            public string Course { get; set; }
        
    }
}

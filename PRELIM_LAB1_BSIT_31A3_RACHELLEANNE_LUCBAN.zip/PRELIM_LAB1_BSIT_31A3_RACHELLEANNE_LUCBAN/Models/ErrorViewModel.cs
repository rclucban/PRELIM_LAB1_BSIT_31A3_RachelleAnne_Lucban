namespace PRELIM_LAB1_BSIT_31A3_RACHELLEANNE_LUCBAN.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}

using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using PRELIM_LAB1_BSIT_31A3_RACHELLEANNE_LUCBAN.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PRELIM_LAB1_BSIT_31A3_RACHELLEANNE_LUCBAN.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            // Task 1: Create variables and store in ViewBag
            string studentName = "Your Name"; // Replace with your actual name for the sample output
            int score = 87;
            bool isPassed = (score >= 75);
            DateTime examDate = DateTime.Now;
            decimal tuitionFee = 15500.75m;

            ViewBag.StudentName = studentName;
            ViewBag.Score = score;
            ViewBag.IsPassed = isPassed;
            ViewBag.ExamDate = examDate;
            ViewBag.TuitionFee = tuitionFee;

            // Task 2: Operators and Control Structures
            string grade;
            if (score >= 90)
            {
                grade = "A";
            }
            else if (score >= 80)
            {
                grade = "B";
            }
            else if (score >= 75)
            {
                grade = "C";
            }
            else
            {
                grade = "F";
            }
            ViewBag.Grade = grade;

            string message = isPassed ? "Congratulations, you passed!" : "Better luck next time.";
            ViewBag.Message = message;

            // Task 3: Loops and Collections
            string[] courses = { "Web Systems", "OOP", "DBMS", "UI/UX", "Networking" };
            string concatenatedCourses = string.Join(", ", courses);
            int numberOfCourses = courses.Length;

            ViewBag.ConcatenatedCourses = concatenatedCourses;
            ViewBag.NumberOfCourses = numberOfCourses;

            // Task 4: Methods
            decimal discount = 10;
            ViewBag.NetFee = ComputeNetFee(tuitionFee, discount);

            // Task 5: Create a Class and Object
            Student sampleStudent = new Student
            {
                Name = "Juan Dela Cruz", // Sample name for display
                Age = 20,
                Course = "Web Systems"
            };
            ViewBag.Student = sampleStudent;

            // Task 6: List of Students
            List<Student> students = new List<Student>
            {
                new Student { Name = "Maria Santos", Age = 20, Course = "Web Systems" },
                new Student { Name = "Pedro Ramirez", Age = 21, Course = "OOP" },
                new Student { Name = "Angelica Reyes", Age = 22, Course = "DBMS" }
            };
            ViewBag.Students = students;

            return View();
        }

        // Task 4: Private Method
        private decimal ComputeNetFee(decimal tuition, decimal discountPercent)
        {
            return tuition - (tuition * discountPercent / 100);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        // Task 7: Convert Privacy.cshtml to AboutMe.cshtml
        public IActionResult AboutMe()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}